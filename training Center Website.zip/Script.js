// JavaScript source code
const myform = document.getElementById('register-form');
const error = document.getElementById('errormessage');
const success = document.getElementById('successmessage');

myform.addEventListener('submit', function (event)){
    //Prevent the page from refreshing
    event.preventDefault();

    //Validate that all fields are filled
    if (!myform.checkValidity) {
        //Display an error message if validation fails
        error.style.display = 'block';
        success.style.display = 'none';
    }
    else {
        //Display a success message if validation passes
        error.style.display = 'none';
        success.style.display = 'block';
    }

    //get student values
    const nameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('Email');
    const courseInput = document.getElementById('courses');
    const name = nameInput.value();
    const email = emailInput.value();
    const course = courseInput.value();

    //Registered Students List
    AddStudentToList(name, email, course);
    myform.reset();

}
const studentList = [];
function AddStudentToList(fullName, email, course) {
    const newStudent = document.createElement('li');

    newStudent.textContent = `Name: ${fullName}, E-mail: ${email}, Course: ${course}`;

    studentList.appendChild(newStudent);
}



